using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyCtrl : MonoBehaviour
{

    //�� ĳ���Ϳ��� �ʿ��� ������Ʈ��
    private Transform EnemyTr;
    private Transform PlayerTr;
    private NavMeshAgent nvAgent;
    private GameObject player;
    private Player playerScript;

    //�� ĳ���Ϳ��� �ʿ��� ������
    public enum EnemyState { idle, trace, attack, die, PlayerDie };
    public EnemyState enemyState = EnemyState.idle;
    public float attackDist = 2.0f;
    public float BornTime;

    public int EnemyNowHp = 10;

    // Use this for initialization
    void Awake()
    {
        player = GameObject.FindWithTag("Player");

        EnemyTr = this.gameObject.GetComponent<Transform>();
        PlayerTr = player.GetComponent<Transform>();
        nvAgent = this.gameObject.GetComponent<NavMeshAgent>();
        playerScript = player.GetComponent<Player>();

    }

    void OnEnable()
    {
        enemyState = EnemyState.idle;
        BornTime = Time.time + 0.5f;

        StartCoroutine(this.CheckEnemyState());
        StartCoroutine(this.EnemyAction());
    }

    /// <summary>
    /// �� ���� Ȯ�� �ڷ�ƾ
    /// </summary>
    IEnumerator CheckEnemyState()
    {
        while (enemyState != EnemyState.die
            && enemyState != EnemyState.PlayerDie)
        {
            yield return new WaitForSeconds(0.2f);

            float dist = Vector3.Distance(PlayerTr.position, EnemyTr.position);

            if (BornTime <= Time.time && enemyState == EnemyState.idle)
            {
                enemyState = EnemyState.trace;
            }

            if (enemyState != EnemyState.idle)
            {

                if (playerScript.PlayerHP == 0)
                {
                    enemyState = EnemyState.PlayerDie;
                }
                else if (dist <= attackDist)
                {
                    enemyState = EnemyState.attack;
                }
                else if (EnemyNowHp <= 0)
                {
                    StopAllCoroutines();
                    enemyState = EnemyState.die;
                    StartCoroutine(EnemyAction());
                }
                else
                {
                    enemyState = EnemyState.trace;
                }

            }

            yield return null;

        }
    }

    IEnumerator EnemyAction()
    {
        while (enemyState != EnemyState.PlayerDie)
        {

            switch (enemyState)
            {

                case EnemyState.trace:
                    nvAgent.SetDestination(PlayerTr.position);
                    break;

                case EnemyState.attack:
                    nvAgent.ResetPath();
                    playerScript.TakeDamage();
                    Debug.Log("Enemy Attack Player!");
                    break;

                case EnemyState.die:
                    nvAgent.ResetPath();
                    this.gameObject.SetActive(false);
                    break;
            }

            yield return null;

        }

    }

    void OnCollisionEnter(Collision coll)
    {
        if (coll.collider.tag == "Bullet")
        {

            Destroy(coll.gameObject);
            EnemyNowHp -= 10;

            Debug.Log("Enemy Hit!");
        }
    }
}