using System.Collections;
using System.Collections.Generic;
using System.IO.Ports;
using UnityEngine;
[RequireComponent(typeof(PlayerMovement))]
[RequireComponent(typeof(GunController))]
public class Player : MonoBehaviour
{

    GunController PlayerGunCtrl;
    public int PlayerHP = 50;
    private float PlayerInvin;
    SerialPort sp = new SerialPort("Com3", 115200);
    int val_x, val_y;
    int acc_x, acc_y;
    int but;
    int A;
    int B;
    private MeshRenderer mesh;

    // Start is called before the first frame update
    void Start()
    {
        sp.Open();
        sp.ReadTimeout = 1;
        PlayerGunCtrl = GetComponent<GunController>();

        PlayerInvin = Time.time;
    }

    // Update is called once per frame
    void Update()
    {
        //Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition + Vector3.forward * 10f);

        //Angle between mouse and this object
        //float angle = AngleBetweenPoints(transform.position, mouseWorldPosition);

        //Ta daa
        //transform.rotation = Quaternion.Euler(new Vector3(0f, angle, 0f));
        if (sp.IsOpen)
        {
            try
            {
                sp.Write("s");
                val_x = sp.ReadByte();
                val_y = sp.ReadByte();
                but = sp.ReadByte();
                acc_x = Mathf.Abs(128 - val_x) / 30;
                acc_x *= acc_x;
                acc_y = Mathf.Abs(128 - val_y) / 30;
                acc_y *= acc_y;
                A = sp.ReadByte();
                B = sp.ReadByte();
                if (val_x > 144)
                {
                    transform.Translate(Vector3.back * Time.deltaTime * acc_x);
                }
                else if (val_x < 112)
                {
                    transform.Translate(Vector3.forward * Time.deltaTime * acc_x);
                }
                if (val_y > 144)
                {
                    transform.Translate(Vector3.right * Time.deltaTime * acc_y);
                }
                else if (val_y < 112)
                {
                    transform.Translate(Vector3.left * Time.deltaTime * acc_y);
                }
                Debug.Log(acc_x + "" + acc_y);
                if (but == 0)
                {
                    PlayerGunCtrl.Shoot();

                    Debug.Log("Input Shot!");
                }
                if (B > 0)
                {
                    transform.localEulerAngles = new Vector3(-B, -200 + A * 4, 0);
                }
                else
                {
                    transform.localEulerAngles = new Vector3(-B, -200 + A * 4, 0);
                }


            }
            catch (System.Exception) { }
        }
        if (Input.GetKey(KeyCode.R)
            && PlayerGunCtrl.newGun.BulletNow != PlayerGunCtrl.newGun.BulletMax)
        {
            PlayerGunCtrl.Reload();
            Debug.Log("Input Reload!");
        }

        if (PlayerHP == 0)
        {
            this.gameObject.SetActive(false);
        }

    }
    public void TakeDamage()
    {
        if (Time.time > PlayerInvin)
        {
            PlayerHP -= 10;
            PlayerInvin = Time.time + 1.0f;

            Debug.Log("Player is Damaged! PlayerHp : " + PlayerHP);

            StartCoroutine(PlayerInvinVisible(PlayerInvin));
        }
    }

    IEnumerator PlayerInvinVisible(float P_InvinTime)
    {
        while (Time.time <= P_InvinTime)
        {
            this.mesh.material.color = new Color(1f, 1f, 1f, 1f);

            yield return new WaitForSeconds(0.1f);

            this.mesh.material.color = new Color(1f, 0f, 0f, 1f);

            yield return new WaitForSeconds(0.1f);
        }

        yield return null;
    }
}



